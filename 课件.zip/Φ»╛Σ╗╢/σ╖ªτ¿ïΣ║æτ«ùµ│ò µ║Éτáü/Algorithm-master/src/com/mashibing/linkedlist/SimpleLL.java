package com.mashibing.linkedlist;

/**
 * simple linked list, one direction
 * @author www.mashibing.com
 *
 */
public class SimpleLL {
	//add insert delete loop
}
