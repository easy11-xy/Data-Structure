package com.mashibing.search;


public class BinarySearch {
}
